
// MFCApplicationExemple1Dlg.cpp : fichier d'implémentation
//

#include "pch.h"
#include "framework.h"
#include "MFCApplicationExemple1.h"
#include "MFCApplicationExemple1Dlg.h"
#include "afxdialogex.h"

#include "resource.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// boîte de dialogue CAboutDlg utilisée pour la boîte de dialogue 'À propos de' pour votre application

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

	// Données de boîte de dialogue
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // Prise en charge de DDX/DDV

	// Implémentation
protected:
	DECLARE_MESSAGE_MAP()
public:
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// boîte de dialogue de CMFCApplicationExemple1Dlg

bool myConnectionState = false;

CMFCApplicationExemple1Dlg::CMFCApplicationExemple1Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_MFCAPPLICATIONEXEMPLE1_DIALOG, pParent)
	, m_XPOSStr(_T(""))
	, m_Status(_T(""))
	, m_Velocity(_T("1 steps/s"))
	, m_BoardStatusStr(_T(""))
	, m_AIN1Str(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_ICNC2 = new cICNC2(false);

	m_ICNC2->HookOnConnectChanged(ConnectedChangedEvent, this);

}

void CMFCApplicationExemple1Dlg::ConnectedChangedEvent(bool ConnectionState, PVOID arg) {
	myConnectionState = ConnectionState;
	//CMFCApplicationExemple1Dlg instance;

	//instance.PostMessage(WM_UpdateStatus, 2, 0);	// send message for connection status update

	//CMFCApplicationExemple1Dlg dlg = new CMFCApplicationExemple1Dlg();
	//PostMessage(WM_UpdateStatus, 2, 0);	// send message for connection status update
}


CMFCApplicationExemple1Dlg::~CMFCApplicationExemple1Dlg(void)
{
	// Todo
	delete m_ICNC2;
}

void CMFCApplicationExemple1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_STATIC4, m_Velocity);
	DDX_Text(pDX, IDC_STATIC_XPOS, m_XPOSStr);
	DDX_Text(pDX, IDC_STATIC_BOARDSTATUS, m_BoardStatusStr);
	DDX_Text(pDX, IDC_STATIC_AIN1, m_AIN1Str);
	DDX_Text(pDX, IDC_STATUS2, m_Status);
	DDX_Control(pDX, IDC_BUTTON_CONNECT, m_ConnectButton);
	DDX_Control(pDX, IDC_OUT1, m_OUT1);
	DDX_Control(pDX, IDC_OUT2, m_OUT2);
	DDX_Control(pDX, IDC_OUT3, m_OUT3);
	DDX_Control(pDX, IDC_OUT4, m_OUT4);
	DDX_Control(pDX, IDC_SLIDER1, m_velocity_slider);
	DDX_Control(pDX, IDC_BUTTONXM, m_button_xm);
	DDX_Control(pDX, IDC_BUTTONXP, m_button_xp);
}

BEGIN_MESSAGE_MAP(CMFCApplicationExemple1Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()


	ON_WM_HSCROLL()
	//ON_WM_LBUTTONDOWN()
	//ON_WM_LBUTTONUP()

	ON_BN_CLICKED(IDC_BUTTON_CONNECT, &CMFCApplicationExemple1Dlg::OnBnClickedButtonConnect)
	ON_MESSAGE(WM_UpdateStatus, &CMFCApplicationExemple1Dlg::OnUpdatestatus)
	ON_MESSAGE(WM_BUTTON_UPDOWN, &CMFCApplicationExemple1Dlg::OnCustomMessageCommand)
	ON_BN_CLICKED(IDC_OUT1, &CMFCApplicationExemple1Dlg::OnClickedOut1)
	ON_BN_CLICKED(IDC_OUT2, &CMFCApplicationExemple1Dlg::OnClickedOut2)
	ON_BN_CLICKED(IDC_OUT3, &CMFCApplicationExemple1Dlg::OnClickedOut3)
	ON_BN_CLICKED(IDC_OUT4, &CMFCApplicationExemple1Dlg::OnClickedOut4)
END_MESSAGE_MAP()


// gestionnaires de messages de CMFCApplicationExemple1Dlg
BOOL CMFCApplicationExemple1Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Ajouter l'élément de menu "À propos de..." au menu Système.

	// IDM_ABOUTBOX doit se trouver dans la plage des commandes système.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Définir l'icône de cette boîte de dialogue.  L'infrastructure effectue cela automatiquement
	//  lorsque la fenêtre principale de l'application n'est pas une boîte de dialogue
	SetIcon(m_hIcon, TRUE);			// Définir une grande icône
	SetIcon(m_hIcon, FALSE);		// Définir une petite icône

	// TODO: ajoutez ici une initialisation supplémentaire
	m_velocity_slider.SetRange(1, 25000);
	m_velocity_slider.SetPos(10000);
	m_Velocity.Format(_T("%d steps/s"), m_velocity_slider.GetPos());
	UpdateData(false);
	return TRUE;  // retourne TRUE, sauf si vous avez défini le focus sur un contrôle
}

void CMFCApplicationExemple1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// Si vous ajoutez un bouton Réduire à votre boîte de dialogue, vous devez utiliser le code ci-dessous
//  pour dessiner l'icône.  Pour les applications MFC utilisant le modèle Document/Vue,
//  cela est fait automatiquement par l'infrastructure.
void CMFCApplicationExemple1Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // contexte de périphérique pour la peinture

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Centrer l'icône dans le rectangle client
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Dessiner l'icône
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}


// Le système appelle cette fonction pour obtenir le curseur à afficher lorsque l'utilisateur fait glisser
//  la fenêtre réduite.
HCURSOR CMFCApplicationExemple1Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


// Handle called when ICNC is disconnected or automatically disconnected after communication error
void myDisconnectedEventHandle(PVOID arg) {
	CMFCApplicationExemple1Dlg* dlg = static_cast<CMFCApplicationExemple1Dlg*>(arg);
	dlg->PostMessage(WM_UpdateStatus, 2, 0);	// send message for connection status update

}

// Handle called from RegisterPeriodicStatusRead
void myTimerCallback(int RequestID, DWORD* data, PVOID arg) {
	bool somechanged = false;
	if (RequestID == 1) {
		CMFCApplicationExemple1Dlg* dlg = static_cast<CMFCApplicationExemple1Dlg*>(arg);
		if ((int)data[0] != dlg->m_StatusBoard) {
			dlg->m_StatusBoard = (int)data[0];
			somechanged = true;
		}		if ((int)data[1] != dlg->m_XPosition) {
			dlg->m_XPosition = (int)data[1];
			somechanged = true;
		}
		if ((int)data[2] != dlg->m_XPosition) {
			dlg->m_AIN1Value = (int)data[2];
			somechanged = true;
		}
		if (somechanged)
			dlg->SendMessage(WM_UpdateStatus, 1, 0);	// Sendmessage and wait for end of treatement
	}



}

// Handle for communication function debug information
void myDebugFunction(PTCHAR message, PVOID Arg) {
	
	OutputDebugString(message);
	OutputDebugString(_T("\n"));
	
}

void CMFCApplicationExemple1Dlg::OnBnClickedButtonConnect()
{
	//ICNC_SetSimulationMode(true);
	// TODO: ajoutez ici le code de votre gestionnaire de notification de contrôle
	if (!m_ICNC2->is_connected()) {
		if (m_ICNC2->Connect() == 1) {
			m_ICNC2->ErrorResetAll();
			if (m_firstConnect) {
				m_ICNC2->RegisterOnDisconnected(myDisconnectedEventHandle, this);
				m_handle_register1 = m_ICNC2->RegisterPeriodicStatusRead(1, ICNC_STATUS_BOARD_STATUS | ICNC_STATUS_ACTUALX | ICNC_STATUS_ANALOG_IN1, 10, (PeriodicReadCallback_t)myTimerCallback, this);
				m_ICNC2->RegisterDebug((DebugCallback_t)myDebugFunction, NULL);
				m_firstConnect = false;
			}
			m_ConnectButton.SetWindowText(_T("Disconnect"));

			// Get actual output state
			DWORD OutputState;
			m_ICNC2->GetAllOutputState(&OutputState);
			m_OUT1.SetCheck((OutputState >> 0) & 1);
			m_OUT2.SetCheck((OutputState >> 1) & 1);
			m_OUT3.SetCheck((OutputState >> 2) & 1);
			m_OUT4.SetCheck((OutputState >> 3) & 1);

		}
	}
	else {
		m_ICNC2->DisConnect();
		m_ConnectButton.SetWindowText(_T("Connect"));
	}
	UpdateData(FALSE);
	PostMessage(WM_UpdateStatus, 2, 0);	// send message for connection status update

	// Sample test of writing coil
	//bool boolValue[96];
	//for (int i = 0; i < 96; i++)
	//	boolValue[i] = (i % 2) == 0 ? false : true;
	//m_ICNC2->SetMBCoils(320, 96, boolValue);

}


// For handling UP and down message from CMyButton class
afx_msg LRESULT CMFCApplicationExemple1Dlg::OnCustomMessageCommand(WPARAM wParam, LPARAM lParam) {
	CMyButton* myButton = reinterpret_cast<CMyButton*>(lParam);

	// Check which button sent event
	if (myButton == &m_button_xp) {
		if (HIWORD(wParam) == WM_LBUTTONDOWN) {
			int Velocity = m_velocity_slider.GetPos();
			m_ICNC2->MoveProfileAbsAsync(1, 250, 100, Velocity, 100, 999999999);
		}
		else if (HIWORD(wParam) == WM_LBUTTONUP) {
			m_ICNC2->SlowStopAxes(ICNC_AXE_X);

		}
		return true;
	}
	if (myButton == &m_button_xm) {
		if (HIWORD(wParam) == WM_LBUTTONDOWN) {
			int Velocity = m_velocity_slider.GetPos();
			m_ICNC2->MoveProfileAbsAsync(1, 250, 100, Velocity, 100, -999999999);

		}
		else if (HIWORD(wParam) == WM_LBUTTONUP) {
			m_ICNC2->SlowStopAxes(ICNC_AXE_X);

		}
		return true;
	}
	return false;
}


afx_msg LRESULT CMFCApplicationExemple1Dlg::OnUpdatestatus(WPARAM wParam, LPARAM lParam)
{
	static int cnt = 0;

	switch (wParam) {
	case 1: // Update X position display
		m_XPOSStr.Format(_T("X = %d steps"), m_XPosition);
		m_BoardStatusStr.Format(_T("Status = 0x%08X"), m_StatusBoard);
		m_AIN1Str.Format(_T("AIN1 = %1.2f V"), (float)m_AIN1Value * 10.0 / 1024.0);

		//unsigned short value[16];
		//m_ICNC2->GetMBHoldingRegisters(4096 + 50, 16, value);
		//for (int i=0; i<16; i++)
		//	value[i] = (value[i]&0xf) | (cnt++ & ~0xf);
		//m_ICNC2->SetMBHoldingRegisters(4096+50, 6, value);

		bool bdata[256];
		m_ICNC2->GetMBInputs(2048, 64, bdata);




		//if (cnt++ % 50 == 0)
		//{
		//	char toto[64];
		//	m_ICNC2->ReadPLCMonitor(toto);
		//	OutputDebugString(toto);

		//	//m_ICNC2->SendPLCCommand("out 1, not getout(1)\n");
		//}

		//DWORD OutputState;
		//m_ICNC2->GetAllOutputState(&OutputState);
		//m_OUT1.SetCheck((OutputState >> 0) & 1);
		//m_OUT2.SetCheck((OutputState >> 1) & 1);
		//m_OUT3.SetCheck((OutputState >> 2) & 1);
		//m_OUT4.SetCheck((OutputState >> 3) & 1);


		UpdateData(FALSE);
		break;
	case 2:	// Disconnected event handle
		m_Status.Format(_T("%s"), m_ICNC2->is_connected() ? _T("Connected") : _T("Disconnected"));
		m_ConnectButton.SetWindowText(m_ICNC2->is_connected() ? _T("Disconnect") : _T("Connect"));
		UpdateData(FALSE);
		break;
	}
	return 0;
}

// Velocity slider event tracking
void CMFCApplicationExemple1Dlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: ajoutez ici le code de votre gestionnaire de messages et/ou les paramètres par défaut des appels

	CSliderCtrl* pSlider = reinterpret_cast<CSliderCtrl*>(pScrollBar);

	// Check which slider sent the notification  
	if (pSlider == &m_velocity_slider)
	{
		int Velocity = m_velocity_slider.GetPos();
		//int Velocity = m_velocity_slider.GetPos() * 100;
		//if (Velocity == 0) Velocity = 1;
		m_Velocity.Format(_T("%d steps/s"), Velocity);
		UpdateData(FALSE);
	}

	else
		CDialogEx::OnHScroll(nSBCode, nPos, pScrollBar);
}


void CMFCApplicationExemple1Dlg::OnClickedOut1()
{
	// TODO: ajoutez ici le code de votre gestionnaire de notification de contrôle
	m_ICNC2->SetOutput(1, m_OUT1.GetCheck());

}
void CMFCApplicationExemple1Dlg::OnClickedOut2()
{
	// TODO: ajoutez ici le code de votre gestionnaire de notification de contrôle
	m_ICNC2->SetOutput(2, m_OUT2.GetCheck());

}
void CMFCApplicationExemple1Dlg::OnClickedOut3()
{
	// TODO: ajoutez ici le code de votre gestionnaire de notification de contrôle
	m_ICNC2->SetOutput(3, m_OUT3.GetCheck());

}
void CMFCApplicationExemple1Dlg::OnClickedOut4()
{
	// TODO: ajoutez ici le code de votre gestionnaire de notification de contrôle
	m_ICNC2->SetOutput(4, m_OUT4.GetCheck());

}
