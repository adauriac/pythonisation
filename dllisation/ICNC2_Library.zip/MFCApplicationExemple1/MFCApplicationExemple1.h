
// MFCApplicationExemple1.h : fichier d'en-tête principal de l'application PROJECT_NAME
//

#pragma once

#ifndef __AFXWIN_H__
	#error "incluez 'pch.h' avant d'inclure ce fichier pour PCH"
#endif

#include "resource.h"		// symboles principaux


// CMFCApplicationExemple1App :
// Consultez MFCApplicationExemple1.cpp pour l'implémentation de cette classe
//

class CMFCApplicationExemple1App : public CWinApp
{
public:
	CMFCApplicationExemple1App();

// Substitutions
public:
	virtual BOOL InitInstance();

// Implémentation

	DECLARE_MESSAGE_MAP()
};

extern CMFCApplicationExemple1App theApp;
