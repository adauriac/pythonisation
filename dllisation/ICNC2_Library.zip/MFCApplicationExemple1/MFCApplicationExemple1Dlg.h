
// MFCApplicationExemple1Dlg.h : fichier d'en-tête
//

#pragma once
#include "CMyButton.h"

#include "../ICNC2_VS/cICNC2.h"
#include "../ICNC2_VS/ICNC2.h"

// boîte de dialogue de CMFCApplicationExemple1Dlg
class CMFCApplicationExemple1Dlg : public CDialogEx
{

// Construction

public:
	CMFCApplicationExemple1Dlg(CWnd* pParent = nullptr);	// constructeur standard

	~CMFCApplicationExemple1Dlg();

	static void ConnectedChangedEvent(bool ConnectionState, PVOID arg);


// Données de boîte de dialogue
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MFCAPPLICATIONEXEMPLE1_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// Prise en charge de DDX/DDV

	cICNC2* m_ICNC2;
	bool m_firstConnect=true;

// Implémentation
protected:
	HICON m_hIcon;
	// Fonctions générées de la table des messages
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonConnect();
	CString m_XPOSStr;
	CString m_BoardStatusStr;
	CString m_AIN1Str;

	CString m_Status;	// Connexion state
	CString m_Velocity;	// Connexion state

	int m_XPosition=MAXINT;
	int m_StatusBoard=MAXINT;
	int m_AIN1Value=MAXINT;

	HANDLE m_handle_register1=NULL;
	
protected:
	afx_msg LRESULT OnUpdatestatus(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnCustomMessageCommand(WPARAM wParam, LPARAM lParam);
public:
	CButton m_ConnectButton;
	CStatic m_ConnexionStateStr;
	CStatic m_ConnexionState;
	CStatic m_StatusText;

	afx_msg void OnClickedOut1();
	afx_msg void OnClickedOut2();
	afx_msg void OnClickedOut3();
	afx_msg void OnClickedOut4();
	CButton m_OUT1;
	CButton m_OUT2;
	CButton m_OUT3;
	CButton m_OUT4;
	CSliderCtrl m_velocity_slider;
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	CMyButton m_button_xm;
	CMyButton m_button_xp;
};
