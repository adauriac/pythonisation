// CMyButton.cpp : fichier d'implémentation
//

#include "pch.h"
#include "MFCApplicationExemple1.h"
#include "CMyButton.h"


// CMyButton

IMPLEMENT_DYNAMIC(CMyButton, CButton)

CMyButton::CMyButton()
{

}

CMyButton::~CMyButton()
{
}


BEGIN_MESSAGE_MAP(CMyButton, CButton)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()



// gestionnaires de messages de CMyButton



// Post a message for Down and up button event

void CMyButton::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ajoutez ici le code de votre gestionnaire de messages et/ou les paramètres par défaut des appels
	CWnd* pMain = AfxGetMainWnd();
	CWnd* pButton = this; // pMain->GetDlgItem(ID_STOP_BUTTON);
	pMain->PostMessage(WM_BUTTON_UPDOWN, MAKEWPARAM(GetDlgCtrlID(), WM_LBUTTONDOWN), (LPARAM)this);// pButton->m_hWnd);
	CButton::OnLButtonDown(nFlags, point);
}


void CMyButton::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ajoutez ici le code de votre gestionnaire de messages et/ou les paramètres par défaut des appels
	CWnd* pMain = AfxGetMainWnd();
	CWnd* pButton = this; // pMain->GetDlgItem(ID_STOP_BUTTON);
	pMain->PostMessage(WM_BUTTON_UPDOWN, MAKEWPARAM(GetDlgCtrlID(), WM_LBUTTONUP), (LPARAM)this); //pButton->m_hWnd);

	CButton::OnLButtonUp(nFlags, point);
}
