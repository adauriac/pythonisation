﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using ICNC2ManagedLibrary;
using CSharpApp1;

namespace CSharpApp1
{
    public partial class FormMain : Form
    {
        static CICNC2 myICNC2 = new CICNC2(true);
        bool m_initDone = false;
        private bool m_PLCisRuning;
        bool state = false;


        public FormMain()
        {
            InitializeComponent();
            // Register delegate for connection changed status
            CICNC2.OnConnectStateChangedEvent += new ICNC2ManagedLibrary.OnConnectedChangeDelegate(ConnectChanged);
            // Force initial state by calling event handle
            ConnectChanged(myICNC2.is_connected());
            myICNC2.ErrorResetAll();
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            myICNC2.DisConnect();
        }


        /// <summary>
        /// Connection status changed event handler
        /// </summary>
        /// <param name="connectionstate"></param>
        public void ConnectChanged(bool connectionstate)
        {
            state = connectionstate;
            pictureBoxConnected.BackColor = connectionstate ? Color.Green : Color.White;
        }


        // Connect and get initial state (not necessary for AutoConnect)
        private void buttonConnect_Click(object sender, EventArgs e)
        {
            // bool used to avoid unnecessary message handling during load of initial state
            m_initDone = false;
            // Try to connect to the InterpCNC
            int res1 = myICNC2.Connect();
            if (!myICNC2.is_connected())
                return; // Return if connexion failed

            // Reset all status bit error
            int res2 = myICNC2.ErrorResetAll();

            // Test of PLC programming
            //string cmd = "new\n";
            //cmd += "10 for zoro = 0 to 10000 : ? \"zoro = \", zoro : out 1, zoro mod 2 : pause 2 : zoro = zoro + 1 : zoro = zoro - 1 : next zoro\n";
            //cmd += "20 for zoro = 0 to 10000 : ? \"Zoro = \", zoro : out 1, zoro mod 2 : pause 2 : zoro = zoro + 1 : zoro = zoro - 1 : next zoro \n"; 
            //myICNC2.SendPLCCommand(cmd);

            Console.WriteLine("Connected to ICNC2 Firmware V{0}.{1}", myICNC2.m_SysInfo.FirmwareVersionH, myICNC2.m_SysInfo.FirmwareVersionL);

            // Test of parameters read
            //for (uint i=1; i<100; i++) {
            //    int prmValue=0;
            //    myICNC2.ReadParameter(i, ref prmValue);
            //    Console.WriteLine("Parameter {0} = {1}", i, prmValue);
            //}


            // Read actual output state to set initial state of checkbox output
            UpdateOutputState();

            bool in1state = true;
            myICNC2.GetInputState(1, ref in1state);


            // Read all SysInfo registers.
            // Those data are also available in myICNC2.m_SysInfo and updated automatically on board connection
            UInt32[] sysinfo = new UInt32[15];
            myICNC2.GetSysInfo((uint)ICNC_SYS_INFO.ALL_SYS_INFO, sysinfo);

            m_initDone = true;
        }


        void UpdateOutputState()
        {
            // Read actual output state to set initial state of checkbox output
            UInt32 ActualOutputState = 0;
            int res3 = myICNC2.GetAllOutputState(ref ActualOutputState);
            checkBox1.Checked = ((ActualOutputState & 1 << 0) != 0);
            checkBox2.Checked = ((ActualOutputState & 1 << 1) != 0);
            checkBox3.Checked = ((ActualOutputState & 1 << 2) != 0);
            checkBox4.Checked = ((ActualOutputState & 1 << 3) != 0);
            checkBox5.Checked = ((ActualOutputState & 1 << 4) != 0);
            checkBox6.Checked = ((ActualOutputState & 1 << 5) != 0);
            checkBox7.Checked = ((ActualOutputState & 1 << 6) != 0);
            checkBox8.Checked = ((ActualOutputState & 1 << 7) != 0);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            // Exemple for reading some status registers
            if (myICNC2.is_connected())
            {

                uint StatusType = (uint)(ICNC2_STATUS.BOARD_STATUS | ICNC2_STATUS.ACTUALX | ICNC2_STATUS.INPUT_STATE | ICNC2_STATUS.BOARD_STATUS2);
                uint[] status = new uint[4];
                if (myICNC2.GetBoardStatus(StatusType, status) != 1)
                    return;

                label1.Text = string.Format("Status = 0x{0:X8} --- Status2 = 0x{1:X8}", status[0], status[3]);
                labelPosX.Text = string.Format("Position X = {0:d}", (int)status[1]);

                uint InputState = status[2];
                Input1.BackColor = ((InputState & (1 << 0)) != 0) ? Color.Red : Color.MistyRose;
                Input2.BackColor = ((InputState & (1 << 1)) != 0) ? Color.Red : Color.MistyRose;
                Input3.BackColor = ((InputState & (1 << 2)) != 0) ? Color.Red : Color.MistyRose;
                Input4.BackColor = ((InputState & (1 << 3)) != 0) ? Color.Red : Color.MistyRose;
                Input5.BackColor = ((InputState & (1 << 4)) != 0) ? Color.Red : Color.MistyRose;
                Input6.BackColor = ((InputState & (1 << 5)) != 0) ? Color.Red : Color.MistyRose;
                Input7.BackColor = ((InputState & (1 << 6)) != 0) ? Color.Red : Color.MistyRose;
                Input8.BackColor = ((InputState & (1 << 7)) != 0) ? Color.Red : Color.MistyRose;

                buttonSendCommand.Enabled = true;

                // Read actual output state (in case of change from PLC program) and update display
                UpdateOutputState();


                if ((status[3] & (uint)ICNC2_STATUS2_BIT.BASIC_RUNNING) != 0)
                {
                    if (!m_PLCisRuning)
                    {
                        textBoxCommand.Enabled = false;
                        buttonSendCommand.Text = "Stop PLC";
                    }
                    m_PLCisRuning = true;

                }
                else
                {
                    if (m_PLCisRuning)
                    {
                        textBoxCommand.Enabled = true;
                        buttonSendCommand.Text = "Send cmd.";
                    }
                    m_PLCisRuning = false;
                }

#if DEBUG
                // Read PLC monitor and display on console
                var MonitorTxt = "";
                if (myICNC2.ReadPLCMonitor(ref MonitorTxt) != 1) return;
                if (MonitorTxt.Length != 0)
                    Console.Write(MonitorTxt);
#endif

            }
            else
            {
                label1.Text = "InterpCNC not connected";
                Input1.BackColor = Color.SeaShell;
                Input2.BackColor = Color.SeaShell;
                Input3.BackColor = Color.SeaShell;
                Input4.BackColor = Color.SeaShell;
                Input5.BackColor = Color.SeaShell;
                Input6.BackColor = Color.SeaShell;
                Input7.BackColor = Color.SeaShell;
                Input8.BackColor = Color.SeaShell;

                buttonSendCommand.Enabled = false;

            }
        }

        // Move X+ to maximum X position
        private void buttonXM_MouseDown(object sender, MouseEventArgs e)
        {

            myICNC2.MoveProfileAbsAsync(1, 100, 25, (uint)trackBarVelocity.Value, 25, -2000000000);

        }

        // Move X- to minimum X position
        private void buttonXP_MouseDown(object sender, MouseEventArgs e)
        {
            myICNC2.MoveProfileAbsAsync(1, 100, 25, (uint)trackBarVelocity.Value, 25, 2000000000);
        }

        private void buttonAxe_MouseUp(object sender, MouseEventArgs e)
        {
            Button myButton = sender as Button;
            if ((myButton == buttonXM) || (myButton == buttonXP))
                myICNC2.SlowStopAxes(1);

        }


        // Change output state
        private void onOutputCheckedChanged(object sender, EventArgs e)
        {
            //if (!m_initDone) return;
            // Output number is define in checkbox Tag field
            CheckBox cbx = sender as CheckBox;

            try
            {
                int OutNumber = Convert.ToInt32(cbx.Tag);
                myICNC2.SetOutput(OutNumber, cbx.Checked);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        // Send PLCBasic command.
        // Please remember a command must be termiated with '\n' caracter
        private void buttonSendCommand_Click(object sender, EventArgs e)
        {
            if (m_PLCisRuning)
            {
                //var encod = Encoding.GetEncoding("iso-8859-1");
                //var s = encod.GetString(new byte[] { 3, (byte)'\n' });
                //myICNC2.SendPLCCommand(s);

                myICNC2.StopPLC();
            }
            else
                myICNC2.SendPLCCommand(textBoxCommand.Text + "\n");
        }

        // For sending a PLC command


        private void textBoxCommand_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                buttonSendCommand_Click(sender, e);
                e.Handled = true;
            }
        }



        private void ButtonMoveProfile_Click(object sender, EventArgs e)
        {

        }


    }
    
}
