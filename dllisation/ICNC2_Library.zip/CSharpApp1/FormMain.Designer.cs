﻿namespace CSharpApp1
{
    partial class FormMain
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.buttonXM = new System.Windows.Forms.Button();
            this.buttonXP = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Input8 = new System.Windows.Forms.PictureBox();
            this.Input7 = new System.Windows.Forms.PictureBox();
            this.Input6 = new System.Windows.Forms.PictureBox();
            this.Input5 = new System.Windows.Forms.PictureBox();
            this.Input4 = new System.Windows.Forms.PictureBox();
            this.Input3 = new System.Windows.Forms.PictureBox();
            this.Input2 = new System.Windows.Forms.PictureBox();
            this.Input1 = new System.Windows.Forms.PictureBox();
            this.textBoxCommand = new System.Windows.Forms.TextBox();
            this.buttonSendCommand = new System.Windows.Forms.Button();
            this.trackBarVelocity = new System.Windows.Forms.TrackBar();
            this.labelPosX = new System.Windows.Forms.Label();
            this.pictureBoxConnected = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Input8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarVelocity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnected)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 25;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // buttonXM
            // 
            this.buttonXM.Location = new System.Drawing.Point(12, 138);
            this.buttonXM.Name = "buttonXM";
            this.buttonXM.Size = new System.Drawing.Size(75, 23);
            this.buttonXM.TabIndex = 0;
            this.buttonXM.Text = "X-";
            this.buttonXM.UseVisualStyleBackColor = true;
            this.buttonXM.MouseDown += new System.Windows.Forms.MouseEventHandler(this.buttonXM_MouseDown);
            this.buttonXM.MouseUp += new System.Windows.Forms.MouseEventHandler(this.buttonAxe_MouseUp);
            // 
            // buttonXP
            // 
            this.buttonXP.Location = new System.Drawing.Point(93, 138);
            this.buttonXP.Name = "buttonXP";
            this.buttonXP.Size = new System.Drawing.Size(75, 23);
            this.buttonXP.TabIndex = 1;
            this.buttonXP.Text = "X+";
            this.buttonXP.UseVisualStyleBackColor = true;
            this.buttonXP.MouseDown += new System.Windows.Forms.MouseEventHandler(this.buttonXP_MouseDown);
            this.buttonXP.MouseUp += new System.Windows.Forms.MouseEventHandler(this.buttonAxe_MouseUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 255);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 19);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(32, 17);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Tag = "1";
            this.checkBox1.Text = "1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.onOutputCheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox8);
            this.groupBox1.Controls.Add(this.checkBox7);
            this.groupBox1.Controls.Add(this.checkBox6);
            this.groupBox1.Controls.Add(this.checkBox5);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Location = new System.Drawing.Point(15, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(311, 45);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Outputs";
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(272, 19);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(32, 17);
            this.checkBox8.TabIndex = 10;
            this.checkBox8.Tag = "8";
            this.checkBox8.Text = "8";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.onOutputCheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(234, 19);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(32, 17);
            this.checkBox7.TabIndex = 9;
            this.checkBox7.Tag = "7";
            this.checkBox7.Text = "7";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.onOutputCheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(196, 19);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(32, 17);
            this.checkBox6.TabIndex = 8;
            this.checkBox6.Tag = "6";
            this.checkBox6.Text = "6";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.onOutputCheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(158, 19);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(32, 17);
            this.checkBox5.TabIndex = 7;
            this.checkBox5.Tag = "5";
            this.checkBox5.Text = "5";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.onOutputCheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(120, 19);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(32, 17);
            this.checkBox4.TabIndex = 6;
            this.checkBox4.Tag = "4";
            this.checkBox4.Text = "4";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.onOutputCheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(82, 19);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(32, 17);
            this.checkBox3.TabIndex = 5;
            this.checkBox3.Tag = "3";
            this.checkBox3.Text = "3";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.onOutputCheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(44, 19);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(32, 17);
            this.checkBox2.TabIndex = 4;
            this.checkBox2.Tag = "2";
            this.checkBox2.Text = "2";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.onOutputCheckedChanged);
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(268, 245);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(58, 23);
            this.buttonConnect.TabIndex = 5;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Input8);
            this.groupBox2.Controls.Add(this.Input7);
            this.groupBox2.Controls.Add(this.Input6);
            this.groupBox2.Controls.Add(this.Input5);
            this.groupBox2.Controls.Add(this.Input4);
            this.groupBox2.Controls.Add(this.Input3);
            this.groupBox2.Controls.Add(this.Input2);
            this.groupBox2.Controls.Add(this.Input1);
            this.groupBox2.Location = new System.Drawing.Point(15, 64);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(311, 62);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Inputs";
            // 
            // Input8
            // 
            this.Input8.BackColor = System.Drawing.SystemColors.Control;
            this.Input8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Input8.Location = new System.Drawing.Point(272, 19);
            this.Input8.Name = "Input8";
            this.Input8.Size = new System.Drawing.Size(15, 27);
            this.Input8.TabIndex = 7;
            this.Input8.TabStop = false;
            // 
            // Input7
            // 
            this.Input7.BackColor = System.Drawing.SystemColors.Control;
            this.Input7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Input7.Location = new System.Drawing.Point(234, 19);
            this.Input7.Name = "Input7";
            this.Input7.Size = new System.Drawing.Size(15, 27);
            this.Input7.TabIndex = 6;
            this.Input7.TabStop = false;
            // 
            // Input6
            // 
            this.Input6.BackColor = System.Drawing.SystemColors.Control;
            this.Input6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Input6.Location = new System.Drawing.Point(196, 19);
            this.Input6.Name = "Input6";
            this.Input6.Size = new System.Drawing.Size(15, 27);
            this.Input6.TabIndex = 5;
            this.Input6.TabStop = false;
            // 
            // Input5
            // 
            this.Input5.BackColor = System.Drawing.SystemColors.Control;
            this.Input5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Input5.Location = new System.Drawing.Point(158, 19);
            this.Input5.Name = "Input5";
            this.Input5.Size = new System.Drawing.Size(15, 27);
            this.Input5.TabIndex = 4;
            this.Input5.TabStop = false;
            // 
            // Input4
            // 
            this.Input4.BackColor = System.Drawing.SystemColors.Control;
            this.Input4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Input4.Location = new System.Drawing.Point(120, 19);
            this.Input4.Name = "Input4";
            this.Input4.Size = new System.Drawing.Size(15, 27);
            this.Input4.TabIndex = 3;
            this.Input4.TabStop = false;
            // 
            // Input3
            // 
            this.Input3.BackColor = System.Drawing.SystemColors.Control;
            this.Input3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Input3.Location = new System.Drawing.Point(78, 19);
            this.Input3.Name = "Input3";
            this.Input3.Size = new System.Drawing.Size(15, 27);
            this.Input3.TabIndex = 2;
            this.Input3.TabStop = false;
            // 
            // Input2
            // 
            this.Input2.BackColor = System.Drawing.SystemColors.Control;
            this.Input2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Input2.Location = new System.Drawing.Point(44, 19);
            this.Input2.Name = "Input2";
            this.Input2.Size = new System.Drawing.Size(15, 27);
            this.Input2.TabIndex = 1;
            this.Input2.TabStop = false;
            // 
            // Input1
            // 
            this.Input1.BackColor = System.Drawing.SystemColors.Control;
            this.Input1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Input1.Location = new System.Drawing.Point(7, 19);
            this.Input1.Name = "Input1";
            this.Input1.Size = new System.Drawing.Size(15, 27);
            this.Input1.TabIndex = 0;
            this.Input1.TabStop = false;
            // 
            // textBoxCommand
            // 
            this.textBoxCommand.Location = new System.Drawing.Point(15, 196);
            this.textBoxCommand.Name = "textBoxCommand";
            this.textBoxCommand.Size = new System.Drawing.Size(190, 20);
            this.textBoxCommand.TabIndex = 7;
            this.textBoxCommand.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCommand_KeyDown);
            // 
            // buttonSendCommand
            // 
            this.buttonSendCommand.Enabled = false;
            this.buttonSendCommand.Location = new System.Drawing.Point(211, 193);
            this.buttonSendCommand.Name = "buttonSendCommand";
            this.buttonSendCommand.Size = new System.Drawing.Size(115, 23);
            this.buttonSendCommand.TabIndex = 8;
            this.buttonSendCommand.Text = "Send PLC cmd.";
            this.buttonSendCommand.UseVisualStyleBackColor = true;
            this.buttonSendCommand.Click += new System.EventHandler(this.buttonSendCommand_Click);
            // 
            // trackBarVelocity
            // 
            this.trackBarVelocity.LargeChange = 25000;
            this.trackBarVelocity.Location = new System.Drawing.Point(174, 132);
            this.trackBarVelocity.Maximum = 100000;
            this.trackBarVelocity.Minimum = 1;
            this.trackBarVelocity.Name = "trackBarVelocity";
            this.trackBarVelocity.Size = new System.Drawing.Size(152, 45);
            this.trackBarVelocity.SmallChange = 50000;
            this.trackBarVelocity.TabIndex = 9;
            this.trackBarVelocity.TickFrequency = 10000;
            this.trackBarVelocity.Value = 10000;
            // 
            // labelPosX
            // 
            this.labelPosX.Location = new System.Drawing.Point(12, 164);
            this.labelPosX.Name = "labelPosX";
            this.labelPosX.Size = new System.Drawing.Size(156, 13);
            this.labelPosX.TabIndex = 10;
            this.labelPosX.Text = "Position X";
            this.labelPosX.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBoxConnected
            // 
            this.pictureBoxConnected.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBoxConnected.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxConnected.Location = new System.Drawing.Point(250, 245);
            this.pictureBoxConnected.Name = "pictureBoxConnected";
            this.pictureBoxConnected.Size = new System.Drawing.Size(17, 23);
            this.pictureBoxConnected.TabIndex = 11;
            this.pictureBoxConnected.TabStop = false;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 288);
            this.Controls.Add(this.pictureBoxConnected);
            this.Controls.Add(this.labelPosX);
            this.Controls.Add(this.trackBarVelocity);
            this.Controls.Add(this.buttonSendCommand);
            this.Controls.Add(this.textBoxCommand);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.buttonConnect);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonXP);
            this.Controls.Add(this.buttonXM);
            this.Name = "FormMain";
            this.Text = "ICNC2 C# library test application";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Input8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Input1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarVelocity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnected)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button buttonXM;
        private System.Windows.Forms.Button buttonXP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox Input8;
        private System.Windows.Forms.PictureBox Input7;
        private System.Windows.Forms.PictureBox Input6;
        private System.Windows.Forms.PictureBox Input5;
        private System.Windows.Forms.PictureBox Input4;
        private System.Windows.Forms.PictureBox Input3;
        private System.Windows.Forms.PictureBox Input2;
        private System.Windows.Forms.PictureBox Input1;
        private System.Windows.Forms.TextBox textBoxCommand;
        private System.Windows.Forms.Button buttonSendCommand;
        private System.Windows.Forms.TrackBar trackBarVelocity;
        private System.Windows.Forms.Label labelPosX;
        private System.Windows.Forms.PictureBox pictureBoxConnected;
    }
}

