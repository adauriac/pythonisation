#pragma once


#include "../ICNC2_VS/cICNC2.h"

using namespace System;
using System::IntPtr;
using System::Runtime::InteropServices::Marshal;

namespace ICNC2ManagedLibrary {

	/// <summary>
	/// A combination of bit can be used to get some status register with GetBoardStatus methode.
	/// You should NEVER request more than 15 registers in one request !!!
	/// </summary>
	[FlagsAttribute] public enum class ICNC2_STATUS : DWORD {
		BOARD_STATUS = 0x00000001,  // get internal board status bits (bits details define with ICNC_STATUS_BIT_xxx constants)
		BUFFER_FREE = 0x00000002,	// get actual command buffer free space for CNC application
		ACTUALX = 0x00000004,	// get actual pos X
		ACTUALY = 0x00000008,	// get actual pos Y
		ACTUALZ = 0x00000010,	// get actual pos Z
		ACTUALA = 0x00000020,	// get actual pos A
		ACTUALB = 0x00000040,	// get actual pos B
		INPUT_STATE = 0x00000080,	// get inputs state
		LAST_PROBE = 0x00000100,  // Get last probe position result
		ANALOG_IN1 = 0x00000200,	// Get analog 1 input value (based on ADC range)
		ANALOG_IN2 = 0x00000400,	// Get analog 2 input value (based on ADC range)
		ANALOG_IN3 = 0x00000800,	// Get analog 3 input value (based on ADC range)
		ANALOG_IN4 = 0x00001000,	// Get analog 4 input value (based on ADC range)
		THC_TARGET = 0x00002000,	// Get actual THC target
		MATRIX_KEY = 0x00004000,	// Get actual matrix key state
		ENCODER = 0x00008000,	// Get actual encoder counter
		A_PULSES_COUNTER = 0x00010000,	// Get actual input A pulses counter
		B_PULSES_COUNTER = 0x00020000,	// Get actual input B pulses counter
		A_PULSES_FREQUENCY = 0x00040000,	// Get actual input A pulses frquency (unit is 1/100Hz)
		B_PULSES_FREQUENCY = 0x00080000,	// Get actual input B pulses counter (unit is 1/100Hz)
		ANALOG_AOUT1 = 0x00100000,	// Get actual analog output 1 state
		ANALOG_AOUT2 = 0x00200000,	// Get actual analog output 2 state
		BOARD_STATUS2 = 0x00400000,	// Get extended board status (Status2)
		DOUT_STATE = 0x00800000	// Get the actual state of DOUT1 to DOUT32
	};

	/// <summary>
	/// Bits details of ICNC2_STATUS.BOARD_STATUS
	/// </summary>
	[FlagsAttribute] public enum class ICNC2_STATUS_BIT : DWORD {
		XMOVING = 0x00000001,	// X axis interpolation moving	}
		YMOVING = 0x00000002,	// Y axis interpolation moving
		ZMOVING = 0x00000004,	// Z axis interpolation moving
		AMOVING = 0x00000008,	// A axis interpolation moving
		BMOVING = 0x00000010,	// B axis interpolation moving
		BUFFER_EMPTY = 0x00000020,	// Commande buffer is empty
		BUFFER_FREZED = 0x00000040,	// Freez buffer is set (buffer commands paused for pre-fill)
		EMERGENCYSTOP = 0x00000080,	// Emergency stop has been pressed
		LOCKED = 0x00000100,	// Board locked (startup, emmergency pressed or stoke limit)
		STROKE_LIMIT = 0x00000200,	// One limit switch has been activated
		HOMING = 0x00000400,	// Homing in progress
		HOMING_ERROR = 0x00000800,	// Homing failed (overstrock)
		PROBING = 0x00001000,	// Probe in progress
		PROBING_ERROR = 0x00002000,	// Probe failed (overstrock or wrong parameters)
		EEWRITE_INPROGRESS = 0x00004000,	// Write in internal EEPROM (parameters) in progress)
		EEWRITE_ERROR = 0x00008000,   // error when read back control after write operation 
		PROMPT_STATE = 0x00010000,	// Get actual prompt management status  
		OVERRIDE = 0x00020000,	// Set if actual override value is <>100%
		OVERRIDE_ALLOWED = 0x00040000,	// Indication of the override status (autorized=0 or not if 1)
		WAIT_INPUT = 0x00080000,	// Timeout occured diring wait input state function0x00010000
		WAIT_INPUT_ERROR = 0x00100000,	// Timeout occured diring wait input state function or wrong data input
		THC_ACTIVATED = 0x00200000,	// THC in ON
		X_ASYNC_MOVING = 0x00400000,	// X asynchonous move in progress
		Y_ASYNC_MOVING = 0x00800000,	// Y asynchonous move in progress
		Z_ASYNC_MOVING = 0x01000000,	// Z asynchonous move in progress
		A_ASYNC_MOVING = 0x02000000,	// A asynchonous move in progress
		B_ASYNC_MOVING = 0x04000000,	// B asynchonous move in progress
		X_LIMIT = 0x08000000,	// X axis limit switch active
		Y_LIMIT = 0x10000000,	// Y axis limit switch active
		Z_LIMIT = 0x20000000,	// Z axis limit switch active
		A_LIMIT = 0x40000000,	// A axis limit switch active
		B_LIMIT = 0x80000000	// B axis limit switch active
	};



	/// <summary>
	/// Bits details of ICNC2_STATUS.BOARD_STATUS2
	/// </summary>
	[FlagsAttribute] public enum class ICNC2_STATUS2_BIT : DWORD {
		XDIRECTION = 0x00000001,	// Actual X axis moving direction
		YDIRECTION = 0x00000002,	// Actual Y axis moving direction
		ZDIRECTION = 0x00000004,	// Actual Z axis moving direction
		ADIRECTION = 0x00000008,	// Actual A axis moving direction
		BDIRECTION = 0x00000010,	// Actual B axis moving direction
		BASIC_TX_OVERRUN = 0x00000020,	// TX buffer used by Print function overrun (when using internal Basic interpreter))
		BASIC_RX_OVERRUN = 0x00000040,	// RX buffer used for transmit program overrun (when using internal Basic interpreter))
		BASIC_RUNNING = 0x00000080, 	// Internal basic program is runing
		DMX_RECEIVED = 0x00000100,	// new DMX frame received, Cleared when call IsDMXReceived
		RECEIPE_CHANGED = 0x00000200,	// Some data changed in receipe memory
		B10 = 0x00000400,
		B11 = 0x00000800,
		B12 = 0x00001000,
		B13 = 0x00002000,
		B14 = 0x00004000,
		B15 = 0x00008000,
		MB_RECEIVED = 0x00010000,			// Data received on Modbus chanel (automatically reset after read)
		MB_USR_RPM_CHANGED = 0x00020000,	// User EEPROM parameter changed (automatically reset after read)
		HOMING_X = 0x00040000,				// Asynchronous homing X in progress	
		HOMING_X_ERROR = 0x00080000,		// Error during Asynchronous homing X 
		HOMING_Y = 0x00100000,				// Asynchronous homing Y in progress
		HOMING_Y_ERROR = 0x00200000,		// Error during Asynchronous homing Y
		HOMING_Z = 0x00400000,
		HOMING_Z_ERROR = 0x00800000,
		HOMING_A = 0x01000000,
		HOMING_A_ERROR = 0x02000000,
		HOMING_B = 0x04000000,
		HOMING_B_ERROR = 0x08000000,
		B28 = 0x10000000,
		B29 = 0x20000000,
		B30 = 0x40000000,
		B31 = 0x80000000
	};

	/// <summary>
	/// Constants to use with GetSysInfo function
	/// </summary>
	public enum class ICNC_SYS_INFO : DWORD {
		BUFFER_SIZE = 0x00000001,   // Taille du buffer de commande (en int32)
		MAX_FREQUENCY = 0x00000002,  // Frequence maximum des déplacements
		APP_VERSION_H = 0x00000004,  // Numéro majeur de version d'application
		APP_VERSION_L = 0x00000008,  // Numéro mineur de version d'application
		LOADER_VERSION_H = 0x00000010,  // Numéro majeur de version du bootloader
		LOADER_VERSION_L = 0x00000020,  // Numéro mineur de version du bootloader
		BOARD_VERSION = 0x00000040,  // Numero de version de carte
		EEPROM_SIZE = 0x00000080,  // Taille EEPROM
		USR_MEM_SIZE = 0x00000100,  // Nombre d'INT32 disponible pour application client (mémoire utilisateur)
		AVAILABLE_AOUT = 0x00000200,  // Nombre de sorties analogiques
		AVAILABLE_AIN = 0x00000400,  // Nombre d'entrées analogiques 
		DAC_RESOLUTION = 0x00000800,  // Analog output converter resolution
		ADC_RESOLUTION = 0x00001000,	// Analog input converter resolution
		AVAILABLE_DOUT = 0x00002000,  // number of available digital output
		AVAILABLE_DIN = 0x00004000,  // Number of available digital input
		ALL_SYS_INFO = 0x00007FFF	// To read all sysInfo together (15 registers required)
	};


	public value struct CSysInfo {
		UINT32 BufferSize;
		UINT32 MaxPulseFrequency;
		UINT32 FirmwareVersionH;
		UINT32 FirmwareVersionL;
		UINT32 BootloaderVersionH;
		UINT32 BootloaderVersionL;
		UINT32 BoardHWVersion;
		UINT32 EEPROMSize;
		UINT32 UserMemAvailable;
		UINT32 AOUTAvailable;
		UINT32 AINAvailable;
		UINT32 DACResolution;
		UINT32 ADCResolution;
		UINT32 DOUTAvailable;
		UINT32 DINAvailable;
	};


	// Derivated class of EventArgs for using with .NET 
	public ref class ConnectionStateChangedEventArgs : EventArgs {
		bool m_ConnectionState;
	public:
		ConnectionStateChangedEventArgs(bool state) {
			m_ConnectionState = state;
		}
		property bool ConnectionState {
			bool get() { return m_ConnectionState; }
		}
	};

	public delegate void OnConnectedChangeDelegate(bool ConnectionState);


	public ref class CICNC2
	{
	public:

		static  event OnConnectedChangeDelegate^ OnConnectStateChangedEvent;



		CICNC2(bool AutoConnect) {

			HANDLE hFile = NULL;
			// The flag OPEN_EXISTING will cause CreateFile to only return a valid
			// handle value if the file exists. If it doesn't it returns INVALID_HANDLE_VALUE
			// and sets the last error to ERROR_FILE_NOT_FOUND.
			hFile = CreateFile(TEXT("ICNC2_VS.DLL"), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
			if (hFile == INVALID_HANDLE_VALUE) {
				DWORD dwError = GetLastError();
				if (dwError == ERROR_FILE_NOT_FOUND) {

					//MessageBox(NULL, _T("ICNC2_VS.DLL not available in your application directory"), _T("Error"), MB_ICONERROR);
				}
				else {
					// unknown error...
					//_tprintf(TEXT("Error 0x%X\n"), dwError);
					//MessageBox(NULL, _T("Error while loading ICNC2_VS.DLL"), _T("Error"), MB_ICONERROR);
				}
			}
			else {
				// the file was found, be sure to close the handle
				CloseHandle(hFile);
			}




			myICNC2 = new cICNC2(AutoConnect);
			//			if (AutoConnect) {
			myICNC2->HookOnConnectChanged((OnConnectChangedEvent_t)(CICNC2::OnConnectChangedEvent), NULL);
			//			}

			if (!myICNC2)
				throw "Fail to create InterpCNC2 instance";
		}

		CICNC2() : CICNC2(false) {}
		//	myICNC2 = new cICNC2();
		//	if (!myICNC2)
		//		throw "Fail to create InterpCNC2 instance";
		//}

		// must be static because of used as callback function
		static void OnConnectChangedEvent(bool ConnectionState, PVOID arg) {
			// Somthing to do
			OnConnectStateChangedEvent(ConnectionState);

		}


		~CICNC2() {
			myICNC2->~cICNC2();
		}

		int Connect(void) {
			int res = myICNC2->Connect();
			// If succes, copy SysInfo from unmanaged to managed data
			if (res == 1 /*ICNCUSB_SUCCESS*/) {
				m_SysInfo.BufferSize = myICNC2->m_SysInfo.BufferSize;
				m_SysInfo.MaxPulseFrequency = myICNC2->m_SysInfo.MaxPulseFrequency;
				m_SysInfo.FirmwareVersionH = myICNC2->m_SysInfo.FirmwareVersionH;
				m_SysInfo.FirmwareVersionL = myICNC2->m_SysInfo.FirmwareVersionL;
				m_SysInfo.BootloaderVersionH = myICNC2->m_SysInfo.BootloaderVersionH;
				m_SysInfo.BootloaderVersionL = myICNC2->m_SysInfo.BootloaderVersionL;
				m_SysInfo.BoardHWVersion = myICNC2->m_SysInfo.BoardHWVersion;
				m_SysInfo.EEPROMSize = myICNC2->m_SysInfo.EEPROMSize;
				m_SysInfo.UserMemAvailable = myICNC2->m_SysInfo.UserMemAvailable;
				m_SysInfo.AOUTAvailable = myICNC2->m_SysInfo.AOUTAvailable;
				m_SysInfo.AINAvailable = myICNC2->m_SysInfo.AINAvailable;
				m_SysInfo.DACResolution = myICNC2->m_SysInfo.DACResolution;
				m_SysInfo.ADCResolution = myICNC2->m_SysInfo.ADCResolution;
				m_SysInfo.DOUTAvailable = myICNC2->m_SysInfo.DOUTAvailable;
				m_SysInfo.DINAvailable = myICNC2->m_SysInfo.DINAvailable;
			}
			return res;
		}


		void DisConnect(void) {
			myICNC2->DisConnect();
		}


		/// <summary>
		/// Set the board in Locked state.
		/// Consequently, all pending mouvement will be stop and command buffer will be flush
		/// New command will be possible only after Unlock call.
		/// </summary>
		/// <param name=""></param>
		/// <returns></returns>
		int Lock(void) {
			return myICNC2->Lock();
		}

		bool is_connected(void) {
			return myICNC2->is_connected();
		}

		/// <summary>
		/// Read of some conteoller system register to get technical informations 
		/// (ie : buffer size, resolution of DAC and ADC, Firmware version...)
		/// Available Systems registers are describe in ICNC_SYS_INFO enum class
		/// </summary>
		/// <param name="SysInfoFlag">Combination of ICNC_SYS_INFO bits</param>
		/// <param name="SysInfoValue">Return value array</param>
		/// <returns></returns>
		int GetSysInfo(DWORD SysInfoFlag, array<UINT32>^ SysInfoValue) {
			pin_ptr<UINT32> p1 = &SysInfoValue[0];
			int res = myICNC2->GetSysInfo(SysInfoFlag, (DWORD*)p1);
			return res;

		}

		/// <summary>
		/// Read one or several status register
		/// The content and size of returned data is depending of the StatusType parameter
		/// You have to provide a pointer to an Array of DWORD with enougth space for return values required.
		/// The size of Status array (from 1 to 32) is equal to the number of bits set in StatusType
		/// </summary>
		/// <param name="StatusType">Bits field combination of required status register.
		///   ICNC_STATUS_BOARD_STATUS       		0x00000001  // get internal board status bits (bits details define with ICNC_STATUS_BIT_xxx constants)
		///   ICNC_STATUS_BUFFER_FREE        		0x00000002	// get actual command buffer free space for CNC application
		///   ICNC_STATUS_ACTUALX            		0x00000004	// get actual pos X
		///   ICNC_STATUS_ACTUALY            		0x00000008	// get actual pos Y
		///   ICNC_STATUS_ACTUALZ            		0x00000010	// get actual pos Z
		///   ICNC_STATUS_ACTUALA            		0x00000020	// get actual pos A
		///   ICNC_STATUS_ACTUALB            		0x00000040	// get actual pos B
		///   ICNC_STATUS_INPUT              		0x00000080	// get inputs state
		///   ICNC_STATUS_LAST_PROBE         		0x00000100  // Get last probe position result
		///   ICNC_STATUS_ANALOG_IN1			  	0x00000200	// Get analog 1 input value (based on ADC range)
		///   ICNC_STATUS_ANALOG_IN2			  	0x00000400	// Get analog 2 input value (based on ADC range)
		///   ICNC_STATUS_ANALOG_IN3			  	0x00000800	// Get analog 3 input value (based on ADC range)
		///   ICNC_STATUS_ANALOG_IN4			  	0x00001000	// Get analog 4 input value (based on ADC range)
		///   ICNC_STATUS_THC_TARGET				0x00002000	// Get actual THC target
		///   ICNC_STATUS_MATRIX_KEY				0x00004000	// Get actual matrix key state
		///   ICNC_STATUS_ENCODER    				0x00008000	// Get actual encoder counter
		///   ICNC_STATUS_A_PULSES_COUNTER		0x00010000	// Get actual input A pulses counter
		///   ICNC_STATUS_B_PULSES_COUNTER		0x00020000	// Get actual input B pulses counter
		///   ICNC_STATUS_A_PULSES_FREQUENCY		0x00040000	// Get actual input A pulses frquency (unit is 1/100Hz)
		///   ICNC_STATUS_B_PULSES_FREQUENCY		0x00080000	// Get actual input B pulses counter (unit is 1/100Hz)
		///   ICNC_STATUS_ANALOG_AOUT1			0x00100000	// Get actual analog output 1 state
		///   ICNC_STATUS_ANALOG_AOUT2      		0x00200000	// Get actual analog output 2 state
		///   ICNC_STATUS_BOARD_STATUS2	        0x00400000	// Get extended board status (Status2. Bits details are define in ICNC_STATUS2_BIT_xxxxxxxxxx)
		/// </param>
		/// <param name="Status">Pointer on DWORD[] where read result will be send
		///     Inside this array, the order depend of the weight of related StatusType bit.
		///     If <c>StatusType = ICNC_STATUS_BOARD_STATUS | ICNC_STATUS_ACTUALX | ICNC_STATUS_ANALOG_IN1 </c>,
		///     Status[0] will be the actual board status
		///     Status[1] will be the actual X motor position
		///     Status[2] will be the analog 1 input value
		/// </param>
		/// <returns>ICNCUSB_SUCCESS if success. Success mean no communication error</returns>	
		/// <exemple>Exemple of GetBoardStatus use in C#
		/// <code>
		/// uint StatusType = (uint)(ICNC2_STATUS.BOARD_STATUS | ICNC2_STATUS.ACTUALX | ICNC2_STATUS.INPUT_STATE | ICNC2_STATUS.BOARD_STATUS2);
		///	uint[] status = new uint[4];	
		///	myICNC2.GetBoardStatus(StatusType, status);
		/// </code>
		/// </exemple>
		int GetBoardStatus(DWORD StatusType, array<UINT32>^ StatusValue) {

			pin_ptr<UINT32> p1 = &StatusValue[0];
			int res = myICNC2->GetBoardStatus(StatusType, (DWORD*)p1);
			return res;
		}



		/// <summary>
		/// Reset error flags define in ErrorStatusBit
		/// </summary>
		/// <param name=ErrorStatusBit">
		/// can be a combination of ICNC_STATUS_BIT_EMERGENCYSTOP, ICNC_STATUS_BIT_LOCKED, ICNC_STATUS_BIT_STROKE_LIMIT,
		/// ICNC_STATUS_BIT_EEWRITE_ERROR, ICNC_STATUS_BIT_HOMING_ERROR
		/// </params>
		/// <returns>1 if communication success</returns>
		int ErrorReset(DWORD ErrorStatusBit) {
			return myICNC2->ErrorReset(ErrorStatusBit);
		}

		int ErrorResetAll() {

			return ErrorReset(ICNC_STATUS_BIT_EMERGENCYSTOP |
				ICNC_STATUS_BIT_LOCKED |
				ICNC_STATUS_BIT_STROKE_LIMIT |
				ICNC_STATUS_BIT_EEWRITE_ERROR |
				ICNC_STATUS_BIT_HOMING_ERROR);
		}


		/// **************************
		/// IO stuffs
		/// **************************
		/// 

		/// <summary>
		/// Read the output state of DOUT1 to DOUT32
		/// </summary>
		/// <param name="OutputState">Return value of actual outputs state</param>
		/// <returns>ICNCUSB_SUCCES if read successfully</returns>
		/// /// <exemple>
		/// UInt32 ActualOutputState = 0;
		/// int res = myICNC2.GetAllOutputState(ref ActualOutputState);
		/// </exemple>
		int GetAllOutputState(UINT32% OutputState) {
			DWORD outputs;
			int res = myICNC2->GetAllOutputState(&outputs);
			OutputState = outputs;
			return res;
		}

		/// <summary>
		/// Read the inputs state DIN1 to DIN32
		/// </summary>
		/// <param name="OutputState">Return value of actual inputs state</param>
		/// <returns>ICNCUSB_SUCCES if read successfully</returns>
		/// /// <exemple>
		/// UInt32 ActualInputState = 0;
		/// int res = myICNC2.GetInputStateAll(ref ActualInputState);
		/// </exemple>
		int GetInputStateAll(UINT32% InputState) {
			DWORD inputs;
			int res = myICNC2->GetInputAll(&inputs);
			InputState = inputs;
			return res;
		}


		/// <summary>
		/// Read one inpute state.
		/// Exemple :
		/// bool in1_state = false; ;
		///	myICNC2.GetInputState(1, ref in1_state);
		/// </summary>
		/// <param name="InNumber"></param>
		/// <param name="State"></param>
		/// <returns></returns>
		int GetInputState(UINT32 InNumber, bool% State) {
			INT inputs;
			int res = myICNC2->GetInput(InNumber, &inputs);
			State = inputs != 0;
			return res;
		}


		int SetOutput(int OutputNumber, bool State) {
			return myICNC2->SetOutput(OutputNumber, State);
		}

		int SetOutputAll(unsigned int State) {
			return myICNC2->SetOutputAll(State);
		}

		int SetAnalog(DWORD AnalogNo,
			DWORD AnalogValue) {
			return myICNC2->SetAnalog(AnalogNo, AnalogValue);
		}



		int ReadUserMem(int MemNumber, UINT32% MemValue) {
			DWORD value;
			int res = myICNC2->ReadUserMem(MemNumber, &value);
			MemValue = value;
			return res;
		}

		int WriteUserMem(int MemNumber, DWORD MemValue) {
			return myICNC2->WriteUserMem(MemNumber, MemValue);
		}


		int WriteParameter(DWORD ParameterID,
			DWORD ParameterValue,
			bool WaitCompletion,
			unsigned int TimeOut) {
			return myICNC2->WriteParameter(ParameterID, ParameterValue, WaitCompletion, TimeOut);
		}

		int ReadParameter(DWORD ParameterID, INT% ParameterValue)
		{
			INT value;
			int res = myICNC2->ReadParameter(ParameterID, &value);
			ParameterValue = value;
			return res;
		}

		int SetSysRegisterValue(int SysItemID, DWORD SysValue) {
			return myICNC2->SetSysRegisterValue(SysItemID, SysValue);

		}

		int GetSysRegisterValue(int SysItemID, DWORD% SysValue) {
			DWORD value;
			int res = myICNC2->GetSysRegisterValue(SysItemID, &value);
			SysValue = value;
			return res;
		}





		/// **************************
		/// Axes stuffs
		/// **************************

		int SetPosition(DWORD Axes, INT PositionX, INT PositionY, INT PositionZ, INT PositionA, INT PositionB) {
			return myICNC2->SetPosition(Axes, PositionX, PositionY, PositionZ, PositionA, PositionB);
		}


		int MoveProfileAbsAsync(DWORD AxisID, DWORD FStartStop, DWORD Accel, DWORD Speed, DWORD Decel, INT Position) {
			return myICNC2->MoveProfileAbsAsync(AxisID, FStartStop, Accel, Speed, Decel, Position);
		}



		int MachineHome(DWORD Axes, DWORD MaxStrokeX, DWORD MaxStrokeY, DWORD MaxStrokeZ, DWORD MaxStrokeA, DWORD MaxStrokeB) {
			return myICNC2->MachineHome(Axes, MaxStrokeX, MaxStrokeY, MaxStrokeZ, MaxStrokeA, MaxStrokeB);
		}


		/// <summary>
		/// Launch homing sequence on one axe. This homing using asynchronous motion and then,
		/// you can send several command to for diffents axes. It will be executed in parallel thread.
		/// ATTENTION : this command don't care about master/slave axes setting
		/// Individual status bit are available for each axes (ICNC_STATUS2_BIT_HOMING_x and ICNC_STATUS2_BIT_HOMING_X_ERROR from ICNC_STATUS_BOARD_STATUS2)
		/// </summary>
		/// <param name="AxeID">Axe ID (from 1 to 5)</param>
		/// <param name="InputNumber">Input number used as reference point (1..32)</param>
		/// <param name="ExpectedInputValue">Input value when switch is engaged (0 for NC, 1 for NO)</param>
		/// <param name="Acceleration_khz_per_s">Acceleration of motion (KHz/s)</param>
		/// <param name="HighSpeed_Hz">Speed for going to the switch (Pulses/s)</param>
		/// <param name="Deceleration_khz_per_s">Deceleration (KHz/s)</param>
		/// <param name="MaxStroke_step">Maximum stroke to reach the switch. It also define the homing motion direction (negative value for homing in negative direction)</param>
		/// <param name="LowSpeed_Hz">Speed used for reversed motion to release the switch</param>
		/// <param name="InitialPosition_step">Position used to initialized the position conter à end of sequence</param>
		/// <returns></returns>
		int AxeHome(DWORD AxeID,
			DWORD InputNumber,
			DWORD ExpectedInputValue,
			DWORD Acceleration_khz_per_s,
			DWORD HighSpeed_Hz,
			DWORD Deceleration_khz_per_s,
			INT   MaxStroke_step,
			DWORD LowSpeed_Hz,
			INT   InitialPosition_step) {

			return myICNC2->AxeHome(AxeID, InputNumber, ExpectedInputValue, Acceleration_khz_per_s, HighSpeed_Hz, Deceleration_khz_per_s, MaxStroke_step, LowSpeed_Hz, InitialPosition_step);
		}


		int Probe(DWORD Axis, DWORD Direction, DWORD InputNo, DWORD InputValue, DWORD MaxStroke, DWORD Speed, DWORD FStart, DWORD Accel, DWORD Decel) {
			return myICNC2->Probe(Axis, Direction, InputNo, InputValue, MaxStroke, Speed, FStart, Accel, Decel);
		}




		/// <summary>
		/// Stop one or several axes with deceleration value based on last move command
		/// This command can be used to stop an Asynchrone motion before excpepted target (or homing sequence or probing sequence)
		/// </summary>
		/// <param name="Axes">Axes ID combination bit (ICNC_AXE_X | ICNC_AXE_Y | ICNC_AXE_Z ...)</param>
		/// <returns>1 if success</returns>	
		int SlowStopAxes(DWORD Axes) {
			return myICNC2->SlowStopAxes(Axes);
		}


		/// <summary>
		/// Stop all axes with decelaration and purge the motion/command buffer
		/// </summary>
		int SlowStopAllAndClear(void) {
			return myICNC2->SlowStopAllAndClear();
		}

		/// Bufferized fonctions for CNC use
		///**************************************************************
		///**************************************************************


		/// <summary>
		/// Move with constant speed from actual position to target position
		/// The speed is related to the major axis speed. All other axes speed will be adjust inside the firmware
		/// according to the major axis speed to get the linear interpolation.
		/// </summary>
		/// <param name="Axes">Axes flags bit to consider (or combiation of ICNC_AXE_x bits)</param>
		/// <param name="Speed">Axis velocity of major axis (Hz or pulses/s)</param>
		/// <param name="PositionX">Target position of X axis. Ignored if bit ICNC_AXE_X is not set in Axes</param>
		/// <param name="PositionY">Target position of Y axis. Ignored if bit ICNC_AXE_Y is not set in Axes</param>
		/// <param name="PositionZ">Target position of Z axis. Ignored if bit ICNC_AXE_Z is not set in Axes</param>
		/// <param name="PositionA">Target position of A axis. Ignored if bit ICNC_AXE_A is not set in Axes</param>
		/// <param name="PositionB">Target position of B axis. Ignored if bit ICNC_AXE_B is not set in Axes</param>
		/// <param name="BufferRequired">Estimation of required space in motion/command buffer for this command</param>
		/// <param name="UsingLocalBuffer">To merge several command before real transmission (for USB communication improvement)</param>
		/// <returns>1 if command successfull</returns>	
		int PushMoveSpeedAbs(DWORD Axes, DWORD Speed, INT PositionX, INT PositionY, INT PositionZ, INT PositionA, INT PositionB, DWORD% BufferRequired, bool UsingLocalBuffer) {

			DWORD bufferUsed;
			int res = myICNC2->PushMoveSpeedAbs(Axes, Speed, PositionX, PositionY, PositionZ, PositionA, PositionB, &bufferUsed, UsingLocalBuffer);
			BufferRequired = bufferUsed;
			return res;

		}

		/// <summary>
		/// Relative move from actual position with constant speed (no speed profile) 
		/// The speed is related to the major axis speed. All other axes speed will be adjust inside the firmware
		/// according to the major axis speed to get the linear interpolation.
		/// </summary>
		/// <param name="Speed">Axis velocity of major axis (Hz or pulses/s)</param>
		/// <param name="MoveX">Increment of X axis. Ignored if value is 0</param>
		/// <param name="MoveY">Increment Y axis.  Ignored if value is 0</param>
		/// <param name="MoveZ">Increment Z axis.  Ignored if value is 0</param>
		/// <param name="MoveA">Increment A axis.  Ignored if value is 0</param>
		/// <param name="MoveB">Increment B axis.  Ignored if value is 0</param>
		/// <param name="BufferRequired">Estimation of required space in motion/command buffer for this command</param>
		/// <param name="UsingLocalBuffer">To merge several command before real transmission (for USB communication improvement)</param>
		/// <returns>1 if command successfull</returns>	
		int PushMoveSpeedRel(DWORD Speed, INT MoveX, INT MoveY, INT MoveZ, INT MoveA, INT MoveB, DWORD% BufferRequired, bool UsingLocalBuffer) {
			DWORD bufferUsed;
			int res = myICNC2->PushMoveSpeedRel(Speed, MoveX, MoveY, MoveZ, MoveA, MoveB, &bufferUsed, UsingLocalBuffer);
			BufferRequired = bufferUsed;
			return res;
		}

		/// <summary>
		/// Relative move from actual position with speed profile 
		/// The speed is related to the major axis speed. All other axes speed will be adjust inside the firmware
		/// according to the major axis speed to get the linear interpolation.
		/// </summary>
		/// <param name="Speed">Axis velocity of major axis (Hz or pulses/s)</param>
		/// <param name="MoveX">Increment of X axis. Ignored if value is 0</param>
		/// <param name="MoveY">Increment Y axis.  Ignored if value is 0</param>
		/// <param name="MoveZ">Increment Z axis.  Ignored if value is 0</param>
		/// <param name="MoveA">Increment A axis.  Ignored if value is 0</param>
		/// <param name="MoveB">Increment B axis.  Ignored if value is 0</param>
		/// <param name="BufferRequired">Estimation of required space in motion/command buffer for this command</param>
		/// <returns>1 if command successfull</returns>	
		int PushMoveToRel(DWORD Speed, INT MoveX, INT MoveY, INT MoveZ, INT MoveA, INT MoveB, DWORD% BufferRequired) {
			DWORD bufferUsed;
			int res = myICNC2->PushMoveSpeedRel(Speed, MoveX, MoveY, MoveZ, MoveA, MoveB, &bufferUsed);
			BufferRequired = bufferUsed;
			return res;
		}

		/// <summary>
		/// Move to absolute position from actual position with speed profile 
		/// The speed is related to the major axis speed. All other axes speed will be adjust inside the firmware
		/// according to the major axis speed to get the linear interpolation.
		/// </summary>
		/// <param name="Axes">Axes flags bit to consider (or combiation of ICNC_AXE_x bits)</param>
		/// <param name="Speed">Axis velocity of major axis (Hz or pulses/s)</param>
		/// <param name="PositionX">Target position of X axis. Ignored if bit ICNC_AXE_X is not set in Axes</param>
		/// <param name="PositionY">Target position of Y axis. Ignored if bit ICNC_AXE_Y is not set in Axes</param>
		/// <param name="PositionZ">Target position of Z axis. Ignored if bit ICNC_AXE_Z is not set in Axes</param>
		/// <param name="PositionA">Target position of A axis. Ignored if bit ICNC_AXE_A is not set in Axes</param>
		/// <param name="PositionB">Target position of B axis. Ignored if bit ICNC_AXE_B is not set in Axes</param>
		/// <param name="BufferRequired">Estimation of required space in motion/command buffer for this command</param>
		/// <returns>1 if command successfull</returns>	
		int PushMoveToAbs(DWORD Axis, DWORD Speed, INT PositionX, INT PositionY, INT PositionZ, INT PositionA, INT PositionB, DWORD% BufferRequired) {
			DWORD bufferUsed;
			int res = myICNC2->PushMoveToAbs(Axis, Speed, PositionX, PositionY, PositionZ, PositionA, PositionB, &bufferUsed);
			BufferRequired = bufferUsed;
			return res;
		}

		/// <summary>
		/// Bufferized write to one of available RAM user memory (m_SysInfo.UserMemAvailable are avaialble)
		/// Could be used to control the buffer treatement
		/// </summary>
		/// <param name="MemNumber">Memory ID from 0 to m_SysInfo.UserMemAvailable-1</param>
		/// <param name="MemValue">New value to write</param>
		/// <returns>1 if success</returns>	
		int PushWriteUserMem(int MemNumber, DWORD MemValue) {
			return myICNC2->PushWriteUserMem(MemNumber, MemValue);
		}

		/// <summary>
		/// Bufferized pause in motion/command buffer excecution
		/// </summary>
		/// <param name="Delay">Delay duration (per 100ms)</param>
		/// <returns>1 if success</returns>	
		int PushDelay(DWORD Delay_ms) {
			return myICNC2->PushDelay(Delay_ms);
		}

		/// <summary>
		/// Bufferized wait for input state. While Input state is different from Expected status, the buffer will be freezed
		/// If expected state don't occur before timeout, the board can be locked and/or the buffer can be flush
		/// </summary>
		/// <param name="InputNo">Input number to control (1..32)</param>
		/// <param name="InputValue">Expected value on the input to continue</param>
		/// <param name="TimeOut">Time allowed to get expected value</param>
		/// <param name="LockIfError">If set, the controlle will be locked to avoid any action in case of timeout</param>
		/// <param name="ClearBufferIfError">If set, the controlle will flush the buffer in case of timeout</param>
		/// <returns>1 if success</returns>	
		int PushWaitForInputState(DWORD InputNo, bool InputValue, DWORD TimeOut, bool LockIfError, bool ClearBufferIfError) {
			return myICNC2->PushWaitForInputState(InputNo, InputValue, TimeOut, LockIfError, ClearBufferIfError);
		}

		/// <summary>
		/// Bufferized Set individual Digital output state
		/// </summary>
		/// <param name="No">DOUT number from 1 to 32</param>
		/// <param name="State">New output state (0 or 1)</param>
		/// <returns>1 if success</returns>	
		int PushSetOutput(int No, bool State) {
			return myICNC2->PushSetOutput(No, State);
		}

		/// <summary>
		/// Bufferized Set all Digital output state together (32 outputs states)
		/// </summary>
		/// <param name="State">New output state</param>
		/// <returns>1 if success</returns>	
		int PushSetOutputAll(unsigned int State) {
			return myICNC2->PushSetOutputAll(State);
		}

		// Modbus data stuff
		// **********************************************************************************************************
		int MBWriteCoils(unsigned int Address, unsigned int NumberOfCoil, array<bool>^ CoilsData) {
			// Modifying the array using a native int* 
			// that points to a pinned pointer in GC'd heap
			pin_ptr<bool> p1 = &CoilsData[0];
			return myICNC2->SetMBCoils(Address, NumberOfCoil, p1);
		}

		int MBReadHoldingRegisters(unsigned int Address, unsigned int number, array<unsigned short>^ Values) {
			pin_ptr<unsigned short> p1 = &Values[0];
			return myICNC2->GetMBHoldingRegisters(Address, number, p1);
		}
		int MBWriteHoldingRegisters(unsigned int Address, unsigned int number, array<unsigned short>^ Values) {
			pin_ptr<unsigned short> p1 = &Values[0];
			return myICNC2->SetMBHoldingRegisters(Address, number, p1);
		}
		int MBReadInputRegisters(unsigned int Address, unsigned int number, array<unsigned short>^ Values) {
			pin_ptr<unsigned short> p1 = &Values[0];
			return myICNC2->GetMBInputRegisters(Address, number, p1);
		}

		int MBReadCoils(unsigned int Address, unsigned int number, array<bool>^ Values) {
			pin_ptr<bool> p1 = &Values[0];
			return myICNC2->GetMBCoils(Address, number, p1);
		}
		int MBReadInputsBit(unsigned int Address, unsigned int number, array<bool>^ Values) {
			pin_ptr<bool> p1 = &Values[0];
			return myICNC2->GetMBInputs(Address, number, p1);
		}



		// PLC Basic stuff
		// **********************************************************************************************************


		/// <summary>
		/// Send a command for the PLC interpreter
		/// To send a program line, the command must start with a line number.
		/// To send a command for immediat execution, just avoid the line number
		/// <code>
		/// SendPLCCommand("out 1, not getout(1)\n");	// Will reverse the OUT1 state immediatly
		/// SendPLCCommand("10 out 1, not getout(1)\n");	// Will write the command in PLC program memory
		/// </code>
		/// </summary>
		/// <param name="cmd">String of PLC command. Must be ended with CR (\n)</param>
		/// <returns></returns>
		int SendPLCCommand(String^ cmd) {
			char* str = (char*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(cmd).ToPointer();
			int res = myICNC2->SendPLCCommand(str);
			System::Runtime::InteropServices::Marshal::FreeHGlobal((IntPtr)str);
			return res;
		}

		/// <summary>
		/// Stop the PLC program if it is runing.
		/// To start it again, you can send a command :  SendPLCCommand("RUN\n") 
		/// </summary>
		/// <returns>ICNCUSB_SUCCESS if command sennt successfully</returns>	
		int StopPLC(void) {
			int res = myICNC2->SendPLCCommand("\3");
			return res;
		}

		/// <summary>
		/// Read the content of the Output monitor buffer used by the PLCBasic intrpreter
		/// </summary>
		/// <exemple>
		/// <code>
		/// var MonitorTxt = "";
		/// myICNC2.ReadPLCMonitor(ref MonitorTxt);
		/// if (MonitorTxt.Length != 0)
		///		Console.Write(MonitorTxt);
		/// </code>
		/// </exemple>
		/// <param name="MonitorTxt">
		/// variable for return the monitor output buffer
		/// </param>
		/// <returns></returns>
		int ReadPLCMonitor(String^% MonitorTxt) {
			char buffer[64];
			int res = myICNC2->ReadPLCMonitor(buffer);
			//String^ str2 = gcnew String(buffer);
			MonitorTxt = gcnew String(buffer);
			return res;

		}
		CSysInfo m_SysInfo;



	private:
		// Handle on cICNC2 class from ICNC2_VS.dll
		cICNC2* myICNC2;
	};
}
