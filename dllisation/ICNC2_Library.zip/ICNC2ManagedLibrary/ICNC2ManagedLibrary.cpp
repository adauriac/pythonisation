#include "pch.h"

#include "ICNC2ManagedLibrary.h"

#include "../ICNC2_VS/cICNC2.h"

