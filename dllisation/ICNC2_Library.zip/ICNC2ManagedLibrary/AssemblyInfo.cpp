#include "pch.h"

using namespace System;
using namespace System::Reflection;
using namespace System::Runtime::CompilerServices;
using namespace System::Runtime::InteropServices;
using namespace System::Security::Permissions;

[assembly:AssemblyTitleAttribute(L"ICNC2ManagedLibrary")];
[assembly:AssemblyDescriptionAttribute(L"")];
[assembly:AssemblyConfigurationAttribute(L"")];
[assembly:AssemblyCompanyAttribute(L"")];
[assembly:AssemblyProductAttribute(L"ICNC2ManagedLibrary")];
[assembly:AssemblyCopyrightAttribute(L"Copyright (c) SOPROLEC 2024")];
[assembly:AssemblyTrademarkAttribute(L"SOPROLEC")];
[assembly:AssemblyCultureAttribute(L"")];

[assembly:AssemblyVersionAttribute(L"1.0.*")];

[assembly:ComVisible(false)];
