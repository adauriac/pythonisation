//{{NO_DEPENDENCIES}}
// Fichier Include généré par Microsoft Visual C++.
// Utilisé par app.rc
